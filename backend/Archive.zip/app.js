'use strict';

let http = require('http'),
    cors = require('cors'),
    express = require('express'),
    app = express()

app.use(cors())

let mysql = require('mysql'), mysqlServer;

    if (1){
        mysqlServer = mysql.createConnection({
            host: process.env.RDS_HOSTNAME,
            user: process.env.RDS_USERNAME,
            password:  process.env.RDS_PASSWORD,
            port: process.env.RDS_PORT,
            database: 'Parthenos'
        });
    }
    else{
        mysqlServer = mysql.createConnection({
            host: '127.0.0.1',
            user: 'root',
            password:   '',
            port: '3306',
            database: 'Parthenos'
        });
    }


var getProblem = function(callback) {

    mysqlServer.query('SELECT * FROM problem WHERE id = 1', function(err, rows, fields) {

        if (!err)
            return callback(null, rows);
        else
            return callback('Cannot connect to db');
    });
}

app.get('/', (req, res) => {
    res.send('This is the Parthenos REST API backend')
});


app.get('/:subject/:id', (req, res, next) => {

    if (req.params['subject'] === 'tutorial' && req.params['id'] === '1') {

        getProblem((err, rows) => {
            if (err) {
                return next(err);
            }

            let objs = [];
            for (let i in rows) {
                objs.push({
                    id: rows[i].id,
                    category: rows[i].category,
                    type: rows[i].type,
                    level: rows[i].level,
                    title: rows[i].title,
                    statement: rows[i].statement,
                    hint: rows[i].hint,
                    solution: rows[i].solution,
                });
            }

            res.json(objs);
        });
    }
    else if (req.params['subject'] === 'competition' && req.params['id'] === '1'){

    }
    else {
        res.send('API no matches');
    }

});


app.listen(process.env.PORT || 3000);
